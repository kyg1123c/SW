// lib/database/database_helper.dart (수정됨)

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/content.dart';
import '../models/review.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    // 🚨 getDatabasesPath() 사용 (path_provider 불필요) 🚨
    String path = join(await getDatabasesPath(), 'reviews.db');

    return await openDatabase(path, version: 1, onCreate: _onCreate);
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE contents(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        category TEXT NOT NULL,
        imageUrl TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE reviews(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        contentId INTEGER NOT NULL,
        rating REAL NOT NULL,
        reviewText TEXT NOT NULL,
        quote TEXT,
        date TEXT NOT NULL,
        FOREIGN KEY (contentId) REFERENCES contents (id) ON DELETE CASCADE
      )
    ''');
  }

  // Content 추가
  Future<int> insertContent(Content content) async {
    final db = await database;
    return await db.insert('contents', {
      'title': content.title,
      'category': content.category,
      'imageUrl': content.imageUrl,
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // Content 조회
  Future<Content?> getContent(int id) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query(
      'contents',
      where: 'id = ?',
      whereArgs: [id],
    );

    if (maps.isEmpty) return null;

    return Content(
      id: maps[0]['id'] as int,
      title: maps[0]['title'] as String,
      category: maps[0]['category'] as String,
      imageUrl: maps[0]['imageUrl'] as String?,
    );
  }

  // 모든 Content 조회
  Future<List<Content>> getAllContents() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.query('contents');

    return List.generate(maps.length, (i) {
      return Content(
        id: maps[i]['id'] as int,
        title: maps[i]['title'] as String,
        category: maps[i]['category'] as String,
        imageUrl: maps[i]['imageUrl'] as String?,
      );
    });
  }

  // Review 추가
  Future<int> insertReview(Review review, int contentId) async {
    final db = await database;
    return await db.insert('reviews', {
      'contentId': contentId,
      'rating': review.rating,
      'reviewText': review.reviewText,
      'quote': review.quote,
      'date': review.date.toIso8601String(),
    }, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // 모든 Review 조회
  Future<List<Review>> getAllReviews() async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.rawQuery('''
      SELECT 
        r.id as reviewId,
        r.rating,
        r.reviewText,
        r.quote,
        r.date,
        c.id as contentId,
        c.title,
        c.category,
        c.imageUrl
      FROM reviews r
      INNER JOIN contents c ON r.contentId = c.id
      ORDER BY r.date DESC
    ''');

    return List.generate(maps.length, (i) {
      return Review(
        id: maps[i]['reviewId'] as int,
        content: Content(
          id: maps[i]['contentId'] as int,
          title: maps[i]['title'] as String,
          category: maps[i]['category'] as String,
          imageUrl: maps[i]['imageUrl'] as String?,
        ),
        rating: maps[i]['rating'] as double,
        reviewText: maps[i]['reviewText'] as String,
        quote: maps[i]['quote'] as String?,
        date: DateTime.parse(maps[i]['date'] as String),
      );
    });
  }

  // 카테고리별 Review 조회
  Future<List<Review>> getReviewsByCategory(String category) async {
    final db = await database;
    final List<Map<String, dynamic>> maps = await db.rawQuery(
      '''
      SELECT 
        r.id as reviewId,
        r.rating,
        r.reviewText,
        r.quote,
        r.date,
        c.id as contentId,
        c.title,
        c.category,
        c.imageUrl
      FROM reviews r
      INNER JOIN contents c ON r.contentId = c.id
      WHERE c.category = ?
      ORDER BY r.date DESC
    ''',
      [category],
    );

    return List.generate(maps.length, (i) {
      return Review(
        id: maps[i]['reviewId'] as int,
        content: Content(
          id: maps[i]['contentId'] as int,
          title: maps[i]['title'] as String,
          category: maps[i]['category'] as String,
          imageUrl: maps[i]['imageUrl'] as String?,
        ),
        rating: maps[i]['rating'] as double,
        reviewText: maps[i]['reviewText'] as String,
        quote: maps[i]['quote'] as String?,
        date: DateTime.parse(maps[i]['date'] as String),
      );
    });
  }

  // Review 수정
  Future<int> updateReview(Review review) async {
    final db = await database;
    return await db.update(
      'reviews',
      {
        'rating': review.rating,
        'reviewText': review.reviewText,
        'quote': review.quote,
        'date': review.date.toIso8601String(),
      },
      where: 'id = ?',
      whereArgs: [review.id],
    );
  }

  // Review 삭제
  Future<int> deleteReview(int id) async {
    final db = await database;
    return await db.delete('reviews', where: 'id = ?', whereArgs: [id]);
  }

  // Content 삭제
  Future<int> deleteContent(int id) async {
    final db = await database;
    return await db.delete('contents', where: 'id = ?', whereArgs: [id]);
  }

  // 데이터베이스 닫기
  Future<void> close() async {
    final db = await database;
    db.close();
  }
}
