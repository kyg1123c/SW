// lib/widgets/review_card.dart (이미지 표시 기능 추가)

import 'dart:io';
import 'package:flutter/material.dart';
import '../models/review.dart';
import '../screens/review_detail_screen.dart';

class ReviewCard extends StatelessWidget {
  final Review review;
  final VoidCallback? onDeleted;

  const ReviewCard({super.key, required this.review, this.onDeleted});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () async {
        final result = await Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => ReviewDetailScreen(review: review),
          ),
        );

        if (result == true && onDeleted != null) {
          onDeleted!();
        }
      },
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: 3,
        margin: const EdgeInsets.only(bottom: 16.0),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 🚨 이미지 표시 영역 수정
              _buildContentImage(),
              const SizedBox(width: 16),

              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      review.content.title,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),

                    _buildCategoryBadge(review.content.category),
                    const SizedBox(height: 8),

                    Text(
                      review.reviewText,
                      style: const TextStyle(fontSize: 14, color: Colors.grey),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 12),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        _buildRatingStars(review.rating),
                        Text(
                          '${review.date.year}.${review.date.month.toString().padLeft(2, '0')}.${review.date.day.toString().padLeft(2, '0')}',
                          style: const TextStyle(
                            fontSize: 12,
                            color: Colors.grey,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // 🚨 이미지 표시 위젯 (수정됨)
  Widget _buildContentImage() {
    return Container(
      width: 80,
      height: 120,
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(8),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child:
            review.content.imageUrl != null &&
                review.content.imageUrl!.isNotEmpty
            ? Image.file(
                File(review.content.imageUrl!),
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  // 🚨 이미지 로드 실패 시 아이콘 표시
                  return Icon(
                    review.content.category == '영화' ? Icons.movie : Icons.book,
                    size: 40,
                    color: Colors.grey.shade600,
                  );
                },
              )
            : Icon(
                review.content.category == '영화' ? Icons.movie : Icons.book,
                size: 40,
                color: Colors.grey.shade600,
              ),
      ),
    );
  }

  Widget _buildCategoryBadge(String category) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: category == '영화' ? Colors.blue.shade100 : Colors.purple.shade100,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        category,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.bold,
          color: category == '영화'
              ? Colors.blue.shade800
              : Colors.purple.shade800,
        ),
      ),
    );
  }

  Widget _buildRatingStars(double rating) {
    List<Widget> stars = [];
    int fullStars = rating.floor();

    for (int i = 0; i < 5; i++) {
      if (i < fullStars) {
        stars.add(const Icon(Icons.star, color: Colors.amber, size: 18));
      } else {
        stars.add(const Icon(Icons.star_border, color: Colors.amber, size: 18));
      }
    }
    return Row(children: stars);
  }
}
