// lib/screens/my_reviews_screen.dart (데이터베이스 연동 버전)

import 'package:flutter/material.dart';
import '../models/review.dart';
import '../widgets/review_card.dart';
import '../database/database_helper.dart';
import 'category_select_screen.dart';

class MyReviewsScreen extends StatefulWidget {
  const MyReviewsScreen({super.key});

  @override
  State<MyReviewsScreen> createState() => _MyReviewsScreenState();
}

class _MyReviewsScreenState extends State<MyReviewsScreen> {
  final DatabaseHelper _dbHelper = DatabaseHelper();
  List<Review> _allReviews = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadReviews();
  }

  // 🚨 데이터베이스에서 리뷰 불러오기 🚨
  Future<void> _loadReviews() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final reviews = await _dbHelper.getAllReviews();
      setState(() {
        _allReviews = reviews;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('리뷰를 불러오는 중 오류가 발생했습니다: $e')));
      }
    }
  }

  Widget _buildReviewCountItem(String title, int count, Color numberColor) {
    return Column(
      children: [
        Text(
          '$count',
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: numberColor,
          ),
        ),
        Text(title, style: const TextStyle(fontSize: 14, color: Colors.grey)),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    // 🚨 데이터베이스의 리뷰로 개수 계산 🚨
    final int totalCount = _allReviews.length;
    final int movieCount = _allReviews
        .where((r) => r.content.category == '영화')
        .length;
    final int bookCount = _allReviews
        .where((r) => r.content.category == '책')
        .length;

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.white,
          elevation: 0,
          toolbarHeight: 190.0,
          flexibleSpace: SafeArea(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    top: 8.0,
                    left: 16.0,
                    right: 16.0,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        '내 리뷰',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          color: Colors.black,
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.settings, color: Colors.black),
                        onPressed: () {},
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8.0),
                Padding(
                  padding: const EdgeInsets.only(
                    left: 16.0,
                    right: 16.0,
                    bottom: 8.0,
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildReviewCountItem('전체', totalCount, Colors.black),
                      _buildReviewCountItem('영화', movieCount, Colors.black),
                      _buildReviewCountItem('책', bookCount, Colors.black),
                    ],
                  ),
                ),
                PreferredSize(
                  preferredSize: const Size.fromHeight(50.0),
                  child: Align(
                    alignment: Alignment.centerLeft,
                    child: TabBar(
                      isScrollable: true,
                      indicatorSize: TabBarIndicatorSize.label,
                      tabs: const [
                        Tab(text: '전체'),
                        Tab(text: '영화'),
                        Tab(text: '책'),
                      ],
                      indicator: const BoxDecoration(),
                      labelPadding: const EdgeInsets.symmetric(horizontal: 8.0),
                    ),
                  ),
                ),
                const SizedBox(height: 8.0),
              ],
            ),
          ),
        ),
        body: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(
                children: [
                  _buildReviewList('전체'),
                  _buildReviewList('영화'),
                  _buildReviewList('책'),
                ],
              ),
        floatingActionButton: FloatingActionButton(
          onPressed: () async {
            // 🚨 화면 복귀 시 리뷰 다시 불러오기 🚨
            await Navigator.push(
              context,
              MaterialPageRoute(
                fullscreenDialog: true,
                builder: (context) => const CategorySelectScreen(),
              ),
            );
            _loadReviews(); // 리뷰 새로고침
          },
          child: const Icon(Icons.add),
        ),
      ),
    );
  }

  Widget _buildReviewList(String category) {
    // 🚨 카테고리별로 필터링 🚨
    final filteredList = _allReviews.where((review) {
      if (category == '전체') return true;
      return review.content.category == category;
    }).toList();

    // 🚨 리뷰가 없을 때 안내 메시지 🚨
    if (filteredList.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              category == '영화'
                  ? Icons.movie_outlined
                  : category == '책'
                  ? Icons.book_outlined
                  : Icons.rate_review_outlined,
              size: 64,
              color: Colors.grey.shade400,
            ),
            const SizedBox(height: 16),
            Text(
              category == '전체'
                  ? '아직 작성된 리뷰가 없습니다'
                  : '아직 작성된 ${category} 리뷰가 없습니다',
              style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
            ),
            const SizedBox(height: 8),
            Text(
              '우측 하단 + 버튼을 눌러\n첫 리뷰를 작성해보세요!',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 14, color: Colors.grey.shade500),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadReviews, // 🚨 당겨서 새로고침 🚨
      child: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: filteredList.length,
        itemBuilder: (context, index) {
          final review = filteredList[index];
          return ReviewCard(review: review, onDeleted: _loadReviews);
        },
      ),
    );
  }
}
