// lib/screens/review_form_screen.dart (이미지 기능 추가)

import 'dart:io';
import 'package:flutter/material.dart';
import '../database/database_helper.dart';
import '../models/content.dart';
import '../models/review.dart';

class ReviewFormScreen extends StatefulWidget {
  final String category;
  final String title;
  final DateTime selectedDate;
  final String? imagePath; // 🚨 이미지 경로 추가

  const ReviewFormScreen({
    super.key,
    required this.category,
    required this.title,
    required this.selectedDate,
    this.imagePath, // 🚨 생성자에 추가
  });

  @override
  State<ReviewFormScreen> createState() => _ReviewFormScreenState();
}

class _ReviewFormScreenState extends State<ReviewFormScreen> {
  double _currentRating = 3.0;
  final TextEditingController _reviewController = TextEditingController();
  final TextEditingController _quoteController = TextEditingController();
  final DatabaseHelper _dbHelper = DatabaseHelper();
  bool _isSaving = false;

  Future<void> _saveReview() async {
    if (_reviewController.text.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('감상평을 입력해 주세요.')));
      return;
    }

    if (_isSaving) return;

    setState(() {
      _isSaving = true;
    });

    try {
      // Content 객체 생성 (이미지 경로 포함)
      final content = Content(
        id: 0,
        title: widget.title,
        category: widget.category,
        imageUrl: widget.imagePath, // 🚨 이미지 경로 저장
      );

      final contentId = await _dbHelper.insertContent(content);

      // Review 객체 생성
      final review = Review(
        id: 0,
        content: content,
        rating: _currentRating,
        reviewText: _reviewController.text,
        quote: _quoteController.text.isNotEmpty ? _quoteController.text : null,
        date: widget.selectedDate,
      );

      await _dbHelper.insertReview(review, contentId);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('리뷰가 저장되었습니다!'),
            backgroundColor: Colors.green,
          ),
        );

        Navigator.popUntil(context, (route) => route.isFirst);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('저장 중 오류가 발생했습니다: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isSaving = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _reviewController.dispose();
    _quoteController.dispose();
    super.dispose();
  }

  Widget _buildContentInfoCard() {
    final dateString =
        '${widget.selectedDate.year}. ${widget.selectedDate.month}. ${widget.selectedDate.day}.';
    final categoryText = widget.category == '영화' ? '관람' : '독서';

    return Card(
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          children: [
            // 🚨 이미지가 있으면 표시, 없으면 아이콘 표시
            Container(
              width: 60,
              height: 80,
              decoration: BoxDecoration(
                color: Colors.grey.shade200,
                borderRadius: BorderRadius.circular(8),
              ),
              child: widget.imagePath != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.file(
                        File(widget.imagePath!),
                        fit: BoxFit.cover,
                      ),
                    )
                  : Icon(
                      widget.category == '영화' ? Icons.movie : Icons.book,
                      size: 30,
                      color: Colors.grey.shade600,
                    ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    widget.title,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    '${widget.category} | $dateString $categoryText',
                    style: TextStyle(color: Colors.grey.shade600),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('리뷰 작성')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildContentInfoCard(),
            const SizedBox(height: 20),
            _buildRatingSection(),
            const SizedBox(height: 20),
            _buildReviewTextSection(),
            const SizedBox(height: 20),
            _buildQuoteSection(),
          ],
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
        child: SizedBox(
          height: 50,
          child: ElevatedButton(
            onPressed: _isSaving ? null : _saveReview,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue.shade700,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            child: _isSaving
                ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(
                      color: Colors.white,
                      strokeWidth: 2,
                    ),
                  )
                : const Text('저장하기', style: TextStyle(fontSize: 18)),
          ),
        ),
      ),
    );
  }

  Widget _buildRatingSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          '별점',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: List.generate(5, (index) {
                return IconButton(
                  icon: Icon(
                    index < _currentRating.floor()
                        ? Icons.star
                        : Icons.star_border,
                    color: Colors.amber,
                    size: 36,
                  ),
                  onPressed: () {
                    setState(() {
                      _currentRating = (index + 1).toDouble();
                    });
                  },
                );
              }),
            ),
            Text(
              _currentRating.toStringAsFixed(1),
              style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildReviewTextSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          '감상평',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _reviewController,
          maxLines: 5,
          decoration: InputDecoration(
            hintText: '이 작품에 대한 감상을 작성해주세요',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
          ),
        ),
      ],
    );
  }

  Widget _buildQuoteSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          '인상 깊은 문장 (선택)',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 10),
        TextField(
          controller: _quoteController,
          maxLines: 3,
          decoration: InputDecoration(
            hintText: '기억에 남는 대사나 문장을 적어보세요',
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
          ),
        ),
      ],
    );
  }
}
