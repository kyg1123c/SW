// lib/screens/search_screen.dart (데이터베이스 연동 버전)

import 'package:flutter/material.dart';
import '../models/content.dart';
import '../models/review.dart';
import '../database/database_helper.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  final DatabaseHelper _dbHelper = DatabaseHelper();

  List<Content> _searchResults = [];
  List<Review> _allReviews = []; // 🚨 전체 리뷰 데이터 (검색용)
  bool _isSearching = false;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadReviews(); // 🚨 초기에 리뷰 데이터 로드
    _searchController.addListener(_onSearch);
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearch);
    _searchController.dispose();
    super.dispose();
  }

  // 🚨 데이터베이스에서 리뷰 불러오기 🚨
  Future<void> _loadReviews() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final reviews = await _dbHelper.getAllReviews();
      setState(() {
        _allReviews = reviews;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
    }
  }

  // 🚨 검색 로직 (데이터베이스의 Content 기준) 🚨
  void _onSearch() {
    final query = _searchController.text.trim();

    if (query.isEmpty) {
      setState(() {
        _isSearching = false;
        _searchResults = [];
      });
    } else {
      // 리뷰에서 Content만 추출하고 중복 제거
      final allContents = _allReviews.map((review) => review.content).toList();

      // 중복 제거 (제목과 카테고리가 같으면 중복으로 간주)
      final uniqueContents = <Content>[];
      final seenTitles = <String>{};

      for (var content in allContents) {
        final key = '${content.title}_${content.category}';
        if (!seenTitles.contains(key)) {
          seenTitles.add(key);
          uniqueContents.add(content);
        }
      }

      // 검색어로 필터링
      final results = uniqueContents
          .where(
            (content) =>
                content.title.toLowerCase().contains(query.toLowerCase()),
          )
          .toList();

      setState(() {
        _isSearching = true;
        _searchResults = results;
      });
    }
  }

  Widget _buildInitialSearchPrompt() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.search, size: 80, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          Text(
            _allReviews.isEmpty
                ? '아직 리뷰가 없습니다\n리뷰를 작성하면 검색할 수 있어요'
                : '제목으로 검색해보세요',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 18, color: Colors.grey.shade600),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchResultItem(Content content) {
    // 🚨 해당 Content의 리뷰 찾기 🚨
    final relatedReview = _allReviews.firstWhere(
      (review) =>
          review.content.title == content.title &&
          review.content.category == content.category,
      orElse: () => _allReviews.first, // 기본값 (실제로는 항상 찾아짐)
    );

    return ListTile(
      leading: Icon(
        content.category == '영화' ? Icons.movie_filter : Icons.book,
        color: content.category == '영화' ? Colors.blue : Colors.purple,
        size: 32,
      ),
      title: Text(
        content.title,
        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
      ),
      subtitle: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 4),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: content.category == '영화'
                      ? Colors.blue.shade100
                      : Colors.purple.shade100,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  content.category,
                  style: TextStyle(
                    fontSize: 12,
                    color: content.category == '영화'
                        ? Colors.blue.shade800
                        : Colors.purple.shade800,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              // 별점 표시
              Row(
                children: [
                  Icon(Icons.star, size: 14, color: Colors.amber.shade700),
                  const SizedBox(width: 2),
                  Text(
                    relatedReview.rating.toStringAsFixed(1),
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey.shade700,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
      trailing: const Icon(
        Icons.arrow_forward_ios,
        size: 16,
        color: Colors.grey,
      ),
      onTap: () {
        // 🚨 리뷰 상세 화면으로 이동 (추후 구현 가능)
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: Text(content.title),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('카테고리: ${content.category}'),
                const SizedBox(height: 8),
                Text('별점: ${relatedReview.rating.toStringAsFixed(1)}'),
                const SizedBox(height: 8),
                Text('감상평: ${relatedReview.reviewText}'),
                if (relatedReview.quote != null) ...[
                  const SizedBox(height: 8),
                  Text('인상 깊은 문장: ${relatedReview.quote}'),
                ],
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text('닫기'),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('검색'),
        backgroundColor: Colors.white,
        surfaceTintColor: Colors.white,
        elevation: 0,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // 검색 입력 필드
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: TextField(
                    controller: _searchController,
                    decoration: InputDecoration(
                      hintText: '제목으로 검색',
                      prefixIcon: const Icon(Icons.search),
                      suffixIcon: _searchController.text.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.close),
                              onPressed: () {
                                _searchController.clear();
                                _onSearch();
                              },
                            )
                          : null,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30.0),
                        borderSide: BorderSide.none,
                      ),
                      filled: true,
                      fillColor: Colors.grey.shade100,
                      contentPadding: const EdgeInsets.symmetric(
                        vertical: 10.0,
                        horizontal: 20.0,
                      ),
                    ),
                  ),
                ),

                // 검색 결과
                Expanded(
                  child: !_isSearching
                      ? _buildInitialSearchPrompt()
                      : _searchResults.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                Icons.search_off,
                                size: 64,
                                color: Colors.grey.shade400,
                              ),
                              const SizedBox(height: 16),
                              Text(
                                '검색 결과가 없습니다',
                                style: TextStyle(
                                  fontSize: 16,
                                  color: Colors.grey.shade600,
                                ),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          itemCount: _searchResults.length,
                          itemBuilder: (context, index) {
                            return _buildSearchResultItem(
                              _searchResults[index],
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}
