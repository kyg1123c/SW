// lib/screens/category_select_screen.dart
import 'package:flutter/material.dart';
import 'add_content_screen.dart'; // 다음 화면 import (2단계에서 만들 예정)

class CategorySelectScreen extends StatelessWidget {
  const CategorySelectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // 상단에 닫기 버튼 (X)
        actions: [
          IconButton(
            icon: const Icon(Icons.close),
            onPressed: () => Navigator.pop(context), // 화면 닫기
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '무엇을 리뷰하시겠어요?',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 30),

            // 1. 영화 선택 카드
            _buildSelectionCard(
              context,
              icon: Icons.movie,
              title: '영화',
              subtitle: '영화 리뷰 작성하기',
              category: '영화',
            ),
            const SizedBox(height: 16),

            // 2. 책 선택 카드
            _buildSelectionCard(
              context,
              icon: Icons.book,
              title: '책',
              subtitle: '책 리뷰 작성하기',
              category: '책',
            ),
          ],
        ),
      ),
    );
  }

  // 카테고리 선택 카드 위젯
  Widget _buildSelectionCard(
    BuildContext context, {
    required IconData icon,
    required String title,
    required String subtitle,
    required String category,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        // 클릭 이벤트를 주기 위한 위젯
        onTap: () {
          // 다음 화면 (AddContentScreen)으로 이동하며 선택된 카테고리 정보를 전달
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AddContentScreen(category: category),
            ),
          );
        },
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Row(
            children: [
              Icon(icon, size: 30, color: Colors.blue.shade700),
              const SizedBox(width: 16),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  Text(subtitle, style: TextStyle(color: Colors.grey.shade600)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
