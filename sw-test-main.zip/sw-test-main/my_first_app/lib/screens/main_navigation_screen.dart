// lib/screens/main_navigation_screen.dart
import 'package:flutter/material.dart';
import 'home_screen.dart';
import 'search_screen.dart';
import 'my_reviews_screen.dart';

class MainNavigationScreen extends StatefulWidget {
  const MainNavigationScreen({super.key});

  @override
  State<MainNavigationScreen> createState() => _MainNavigationScreenState();
}

class _MainNavigationScreenState extends State<MainNavigationScreen> {
  // 현재 선택된 인덱스를 0번 (홈)으로 변경하는 것이 일반적이지만,
  // 기존 설정대로 '내 리뷰' 화면이 기본 (2)으로 유지합니다.
  int _selectedIndex = 2;

  final List<Widget> _screens = [
    const HomeScreen(),
    const SearchScreen(),
    const MyReviewsScreen(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        selectedItemColor: Colors.blue,
        unselectedItemColor: Colors.grey,

        // [추가/수정] BottomNavigationBarType.fixed: 탭이 3개이므로 레이블이 항상 보이도록 합니다.
        type: BottomNavigationBarType.fixed,

        items: <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            // [수정] 선택 상태에 따라 아이콘을 변경합니다. (selectedIndex == 0: 채워진 아이콘)
            icon: Icon(_selectedIndex == 0 ? Icons.home : Icons.home_outlined),
            label: '홈',
          ),
          BottomNavigationBarItem(
            // [수정] 검색 아이콘은 채워진 모양이 덜 흔하므로, Icons.search를 유지합니다.
            icon: const Icon(Icons.search),
            label: '검색',
          ),
          BottomNavigationBarItem(
            // [수정] 선택 상태에 따라 아이콘을 변경합니다. (selectedIndex == 2: 채워진 아이콘)
            icon: Icon(
              _selectedIndex == 2 ? Icons.person : Icons.person_outline,
            ),
            label: '내 리뷰',
          ),
        ],
      ),
    );
  }
}
