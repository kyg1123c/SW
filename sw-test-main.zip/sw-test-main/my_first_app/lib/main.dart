// lib/main.dart
import 'package:flutter/material.dart';
// 새로 만든 main_navigation_screen을 import 합니다.
import 'package:my_first_app/screens/main_navigation_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Review Mate App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      // 홈 화면을 메인 내비게이션으로 설정
      home: const MainNavigationScreen(),
    );
  }
}
