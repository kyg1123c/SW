// lib/models/content.dart
class Content {
  final int id;
  final String title;
  final String category; // '영화' 또는 '책'
  final String? imageUrl; // 포스터 또는 표지 이미지 URL

  Content({
    required this.id,
    required this.title,
    required this.category,
    this.imageUrl,
  });

  // 데이터베이스/JSON 등에서 데이터를 받아 객체로 변환하는 팩토리 메서드
  factory Content.fromJson(Map<String, dynamic> json) {
    return Content(
      id: json['id'] as int,
      title: json['title'] as String,
      category: json['category'] as String,
      imageUrl: json['imageUrl'] as String?,
    );
  }
}
