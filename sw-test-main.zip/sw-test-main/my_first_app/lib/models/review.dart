// lib/models/review.dart
import 'content.dart';

class Review {
  final int id; // 리뷰 고유 ID
  final Content content; // 리뷰 대상 (Content 객체)
  final double rating; // 별점 (0.0 ~ 5.0)
  final String reviewText; // 감상평
  final String? quote; // 인상 깊은 문장 (선택 사항)
  final DateTime date; // 작성 날짜

  Review({
    required this.id,
    required this.content,
    required this.rating,
    required this.reviewText,
    this.quote,
    required this.date,
  });

  // 데이터베이스/JSON 등에서 데이터를 받아 객체로 변환하는 팩토리 메서드
  factory Review.fromJson(Map<String, dynamic> json) {
    return Review(
      id: json['id'] as int,
      content: Content.fromJson(json['content']), // Content 객체도 변환
      rating: json['rating'] as double,
      reviewText: json['reviewText'] as String,
      quote: json['quote'] as String?,
      // 데이터베이스에서 저장된 String 형태의 날짜를 DateTime 객체로 변환
      date: DateTime.parse(json['date'] as String),
    );
  }
}
